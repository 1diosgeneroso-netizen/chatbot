El script npm run preparar-estatuto descarga el PDF oficial y genera estatuto.pdf y estatuto.txt. Esos archivos locales están excluidos de Git mediante .gitignore.
